import random
import pygame
from game.button import ChoiceButton

class GameEngine:
    def __init__(self, width, height):
        self.width = width
        self.height = height

        self.choices = ["ROCK", "PAPER", "SCISSORS"]
        btn_w, btn_h = 130, 50
        gap = 20
        total_w = 3 * btn_w + 2 * gap
        start_x = (width - total_w) // 2
        btn_y = height - 85

        self.buttons = [
            ChoiceButton("ROCK", pygame.Rect(start_x, btn_y, btn_w, btn_h), (160, 50, 50), (200, 70, 70)),
            ChoiceButton("PAPER", pygame.Rect(start_x + btn_w + gap, btn_y, btn_w, btn_h), (40, 100, 170), (60, 130, 210)),
            ChoiceButton("SCISSORS", pygame.Rect(start_x + 2 * (btn_w + gap), btn_y, btn_w, btn_h), (180, 140, 30), (220, 180, 50)),
        ]

        self.player_choice = None
        self.cpu_choice = None
        self.result_text = "Make your move!"
        self.result_color = (220, 225, 235)

        self.player_score = 0
        self.cpu_score = 0
# Task 2                                                                                Task 2
        self.target_score = 3
        self.game_over = False
        self.winner = None

        self.round_resolved_time = 0
        self.display_duration = 1800
        self.showing_result = False

        self.font_title = pygame.font.SysFont(None, 36)
        self.font_hud = pygame.font.SysFont(None, 26)
        self.font_arena = pygame.font.SysFont(None, 32)

#Task 3        
        self.player_history = []
        self.history_limit = 8

# Task 4
        self.reveal_active = False
        self.reveal_start_time = 0
        self.reveal_duration = 900


    def determine_winner(self, player, cpu):
        if player == cpu:
            return "TIE"
#   TASK 1                                                                         TASK 1  
        rules = {
    ("ROCK", "SCISSORS"): "PLAYER",
    ("SCISSORS", "PAPER"): "PLAYER",
    ("PAPER", "ROCK"): "PLAYER",

    ("SCISSORS", "ROCK"): "CPU",
    ("PAPER", "SCISSORS"): "CPU",
    ("ROCK", "PAPER"): "CPU",
}
        return rules.get((player, cpu), "TIE")
    def get_adaptive_cpu_choice(self):
        # Not enough history yet: choose randomly
        if len(self.player_history) < 3:
            return random.choice(self.choices)

        counts = {
            "ROCK": self.player_history.count("ROCK"),
            "PAPER": self.player_history.count("PAPER"),
            "SCISSORS": self.player_history.count("SCISSORS")
        }

        most_common = max(counts, key=counts.get)

        counter_move = {
            "ROCK": "PAPER",
            "PAPER": "SCISSORS",
            "SCISSORS": "ROCK"
        }

        # 70% chance to counter the player's most common move
        # 30% chance to remain random
        if random.random() < 0.7:
            return counter_move[most_common]

        return random.choice(self.choices)

    def play_round(self, choice):
        if self.game_over:
            return
        self.player_choice = choice
        # Task 3
        self.player_history.append(choice)
        
        if len(self.player_history) > self.history_limit:
            self.player_history.pop(0)
        self.cpu_choice = self.get_adaptive_cpu_choice()

        outcome = self.determine_winner(self.player_choice, self.cpu_choice)
        if outcome == "PLAYER":
            self.player_score += 1
            self.result_text = f"You Win! {self.player_choice} beats {self.cpu_choice}."
            self.result_color = (80, 230, 120)
        elif outcome == "CPU":
            self.cpu_score += 1
            self.result_text = f"You Lose! {self.cpu_choice} beats {self.player_choice}."
            self.result_color = (240, 80, 80)
        else:
            self.result_text = f"It's a Draw! Both picked {self.player_choice}."
            self.result_color = (240, 210, 80)

        self.showing_result = True
        self.round_resolved_time = pygame.time.get_ticks()
        
        
        # Task 2
        if self.player_score >= self.target_score:
            self.game_over = True
            self.winner = "PLAYER"
            self.result_text = "PLAYER WINS THE MATCH!"
            self.result_color = (80, 230, 120)

        elif self.cpu_score >= self.target_score:
            self.game_over = True
            self.winner = "CPU"
            self.result_text = "CPU WINS THE MATCH!"
            self.result_color = (240, 80, 80)

        self.reveal_active = True
        self.reveal_start_time = pygame.time.get_ticks()
        
# Task 2
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
            if self.game_over:
                self.reset_game()
                return

        if self.game_over:
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for btn in self.buttons:
                if btn.contains(event.pos):
                    self.play_round(btn.choice_name)
                    break
# Task 2
    def reset_game(self):
        self.player_choice = None
        self.cpu_choice = None

        self.player_score = 0
        self.cpu_score = 0

        self.result_text = "Make your move!"
        self.result_color = (220, 225, 235)

        self.showing_result = False
        self.game_over = False
        self.winner = None
        # Task 3
        self.player_history = []


    def update(self):
        now = pygame.time.get_ticks()
        if self.showing_result and (now - self.round_resolved_time >= self.display_duration):
            self.player_choice = None
            self.cpu_choice = None
            self.result_text = "Make your move!"
            self.result_color = (190, 195, 205)
            self.showing_result = False

    def draw_gesture_icon(self, screen, choice, center, size=55):
        x, y = center

        if choice == "ROCK":
            pygame.draw.circle(
                screen,
                (150, 150, 160),
                (x, y),
                size // 2
            )

            pygame.draw.circle(
                screen,
                (190, 190, 200),
                (x - 12, y - 10),
                size // 6
            )

        elif choice == "PAPER":
            rect = pygame.Rect(
                x - size // 2,
                y - size // 2,
                size,
                size + 15
            )

            pygame.draw.rect(
                screen,
                (230, 230, 240),
                rect,
                border_radius=6
            )

            for i in range(3):
                pygame.draw.line(
                    screen,
                    (150, 150, 160),
                    (x - 15, y - 10 + i * 10),
                    (x + 15, y - 10 + i * 10),
                    2
                )

        elif choice == "SCISSORS":
            pygame.draw.line(
                screen,
                (210, 210, 220),
                (x - 25, y - 20),
                (x + 20, y + 20),
                8
            )

            pygame.draw.line(
                screen,
                (210, 210, 220),
                (x - 25, y + 20),
                (x + 20, y - 20),
                8
            )

            pygame.draw.circle(
                screen,
                (180, 180, 190),
                (x - 22, y - 20),
                9,
                3
            )

            pygame.draw.circle(
                screen,
                (180, 180, 190),
                (x - 22, y + 20),
                9,
                3
                )

    def draw_reveal_animation(self, screen):
        elapsed = pygame.time.get_ticks() - self.reveal_start_time

        if elapsed >= self.reveal_duration:
            self.reveal_active = False
            return False

        progress = elapsed / self.reveal_duration

        shake = int(10 * (1 - progress))

        if (elapsed // 100) % 2 == 0:
            offset = shake
        else:
            offset = -shake

        font = pygame.font.SysFont(None, 30)

        text = font.render(
            "GET READY...",
            True,
            (255, 255, 255)
        )

        screen.blit(
            text,
            (
                self.width // 2 - text.get_width() // 2,
                100
            )
        )

        self.draw_gesture_icon(
            screen,
            "ROCK",
            (self.width // 4 + offset, 170)
        )

        self.draw_gesture_icon(
            screen,
            "ROCK",
            (3 * self.width // 4 - offset, 170)
        )

        return True


    def render(self, screen):
        screen.fill((24, 28, 36))

        title_surf = self.font_title.render(
            "Rock Paper Scissors",
            True,
            (245, 245, 245)
        )
        screen.blit(
            title_surf,
            (self.width // 2 - title_surf.get_width() // 2, 14)
        )

        # Scores
        p_surf = self.font_hud.render(
            f"Player Score: {self.player_score}",
            True,
            (100, 180, 255)
        )

        c_surf = self.font_hud.render(
            f"CPU Score: {self.cpu_score}",
            True,
            (255, 120, 120)
        )

        screen.blit(p_surf, (35, 52))
        screen.blit(
            c_surf,
            (self.width - c_surf.get_width() - 35, 52)
        )

        pygame.draw.line(
            screen,
            (45, 52, 66),
            (25, 82),
            (self.width - 25, 82),
            2
        )

        # =========================
        # TASK 4: REVEAL ANIMATION
        # =========================
        if self.reveal_active:

            animation_running = self.draw_reveal_animation(screen)

            if not animation_running:
                self.reveal_active = False

        else:

            # Show player's and CPU's choices
            p_str = self.player_choice if self.player_choice else "--"
            c_str = self.cpu_choice if self.cpu_choice else "--"

            arena_p = self.font_arena.render(
                f"Your Pick:  {p_str}",
                True,
                (225, 225, 230)
            )

            arena_c = self.font_arena.render(
                f"CPU Pick:  {c_str}",
                True,
                (225, 225, 230)
            )

            screen.blit(
                arena_p,
                (self.width // 2 - arena_p.get_width() // 2, 115)
            )

            screen.blit(
                arena_c,
                (self.width // 2 - arena_c.get_width() // 2, 155)
            )

            # Player icon
            if self.player_choice:
                self.draw_gesture_icon(
                    screen,
                    self.player_choice,
                    (self.width // 4, 170)
                )

            # CPU icon
            if self.cpu_choice:
                self.draw_gesture_icon(
                    screen,
                    self.cpu_choice,
                    (3 * self.width // 4, 170)
                )

        # Result text
        res_surf = self.font_arena.render(
            self.result_text,
            True,
            self.result_color
        )

        screen.blit(
            res_surf,
            (
                self.width // 2 - res_surf.get_width() // 2,
                205
            )
        )

        # Buttons
        for btn in self.buttons:
            btn.render(screen)

        # =========================
        # TASK 2: GAME OVER SCREEN
        # =========================
        if self.game_over:

            overlay = pygame.Surface(
                (self.width, self.height),
                pygame.SRCALPHA
            )

            overlay.fill((0, 0, 0, 170))
            screen.blit(overlay, (0, 0))

            game_over_font = pygame.font.SysFont(None, 50)

            winner_text = (
                "PLAYER WINS!"
                if self.winner == "PLAYER"
                else "CPU WINS!"
            )

            winner_surf = game_over_font.render(
                winner_text,
                True,
                (255, 255, 255)
            )

            screen.blit(
                winner_surf,
                (
                    self.width // 2 - winner_surf.get_width() // 2,
                    self.height // 2 - 40
                )
            )

            restart_font = pygame.font.SysFont(None, 28)

            restart_surf = restart_font.render(
                "Press R to restart",
                True,
                (220, 220, 220)
            )

            screen.blit(
                restart_surf,
                (
                    self.width // 2 - restart_surf.get_width() // 2,
                    self.height // 2 + 20
                )
            )